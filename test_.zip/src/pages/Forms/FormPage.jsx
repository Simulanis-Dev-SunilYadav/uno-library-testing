import React, { useState } from "react";
import SimForm from "./SimForm";
import SimSelect from './SimSelect/SimSelect'
import SimRadio from "./SimRadio/SimRadio";

const FormPage = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
  });

  const [isTouched, setIsTouched] = useState({
    name: false,
    email: false,
    phone: false,
    password: false,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleFocus = (e) => {
    const { name } = e.target;
    setIsTouched((prevTouched) => ({
      ...prevTouched,
      [name]: true,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate all fields before submitting
    const validName = document.querySelector("input[name='name']").checkValidity();
    const validEmail = document.querySelector("input[name='email']").checkValidity();
    const validPhone = document.querySelector("input[name='phone']").checkValidity();
    const validPassword = document.querySelector("input[name='password']").checkValidity();

    if (validName && validEmail && validPhone && validPassword) {
      console.log("Form Data Submitted:", formData);
    } else {
      console.log("Form validation failed");
    }
  };



  const options = [
    { value: 'male', label: 'Male' },
    { value: 'female', label: 'Female' }
  ]

  return (
    <div className="container mt-4">
      <h2>Form with Conditional Validation</h2>
      <form onSubmit={handleSubmit}>
        <div className="row">
          <div className="col-md-6">
            <SimForm
              type="text"
              placeholder="Enter your name"
              label="Name"
              value={formData.name}
              onChange={handleChange}
              name="name"
              isTouched={isTouched.name}
              setIsTouched={(val) => setIsTouched({ ...isTouched, name: val })}
            />
          </div>
          <div className="col-md-6">
            <SimForm
              type="email"
              placeholder="Enter your email"
              label="Email"
              value={formData.email}
              onChange={handleChange}
              name="email"
              isTouched={isTouched.email}
              setIsTouched={(val) => setIsTouched({ ...isTouched, email: val })}
            />
          </div>
          <div className="col-md-6">
            <SimForm
              type="tel"
              placeholder="Enter your phone number"
              label="Phone"
              value={formData.phone}
              onChange={handleChange}
              name="phone"
              isTouched={isTouched.phone}
              setIsTouched={(val) => setIsTouched({ ...isTouched, phone: val })}
            />
          </div>
          <div className="col-md-6">
            <SimForm
              type="password"
              placeholder="Enter your password"
              label="Password"
              value={formData.password}
              onChange={handleChange}
              name="password"
              isTouched={isTouched.password}
              setIsTouched={(val) => setIsTouched({ ...isTouched, password: val })}
            />
          </div>
          <div className="col-md-6">
            <SimSelect
              options={options}
              multiselet={false}
              label="Gender"
              placeholder="Select Gender"
            />
          </div>
          <div className="col-md-6">
              <SimRadio
                  label="Primary"
              />
              <SimRadio
                  label="Secondry"
              />
          </div>
        </div>
        <button type="submit" className="btn btn-primary mt-3">
          Submit
        </button>
      </form>
    </div>
  );
};

export default FormPage;

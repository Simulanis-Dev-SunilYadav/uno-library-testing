import React from 'react'
import Select from 'react-select';

const SimSelect = ({options, label, placeholder, multiselet}) => {
  
  return (
    <>
      <label htmlFor="">{label}</label>
      <Select
        options={options}
        placeholder={placeholder}
        isMulti={multiselet}
      />
    </>
  )
}

export default SimSelect

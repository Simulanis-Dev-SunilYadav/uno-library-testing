import React, { useState, forwardRef } from "react";
import { validateEmail, validatePhone, validatePassword } from "./ValidationFn";

const SimForm = forwardRef(({ 
  type, 
  placeholder, 
  label, 
  value, 
  onChange, 
  errorMessage, 
  className, 
  name, 
  isTouched, // Track if the input was touched
  setIsTouched, // Set if the input is touched
}, ref) => {
  const [isValid, setIsValid] = useState(true);  // Track the validity of the input
  const [localError, setLocalError] = useState("");  // Local error message

  const handleFocus = () => {
    setIsTouched(true);  // Mark the field as touched
  };

  const handleBlur = () => {
    setIsTouched(true);  // Mark the field as touched
    validateInput(value);  // Validate on blur
  };

  const validateInput = (inputValue) => {
    let valid = true;
    let error = "";

    if (type === "email") {
      valid = validateEmail(inputValue);
      if (!valid) error = "Please enter a valid email address.";
    } else if (type === "tel") {
      valid = validatePhone(inputValue);
      if (!valid) error = "Please enter a valid 10-digit phone number.";
    } else if (type === "password") {
      valid = validatePassword(inputValue);
      if (!valid) error = "Password must be 8+ characters, with an uppercase & a number.";
    } else {
      valid = inputValue.trim() !== "";  // If no specific validation, check if the field is not empty
      if (!valid) error = "This field is required.";
    }

    setIsValid(valid);
    setLocalError(error);  // Update the error message
    return valid;
  };

  const inputClassNames = `form-control ${!isValid && isTouched ? "border-danger" : ""} ${className || ""}`;

  return (
    <div>
      {label && <label>{label}</label>}
      <input
        ref={ref}
        name={name}
        className={inputClassNames}
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => {
          onChange(e); // Update the value on change
          if (isTouched) validateInput(e.target.value); // Validate while typing if touched
        }}
        onFocus={handleFocus}
        onBlur={handleBlur}
      />
      {(!isValid || !value) && isTouched && (
        <div style={{ color: "red", fontSize: "0.8rem", marginTop: "0.5rem" }}>
          {localError || errorMessage}  {/* Display either the local or passed error */}
        </div>
      )}
    </div>
  );
});

export default SimForm;

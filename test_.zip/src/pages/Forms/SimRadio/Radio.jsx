import React, { useState } from 'react';
import SimRadio from './SimRadio';

const Radio = () => {
  const [selectedValue, setSelectedValue] = useState('');
  const handleChange = (event) => {
    setSelectedValue(event.target.id);
  };

  return (
    <>
      <SimRadio
        label="First"
        disabled={false}
        name="first"
        id="first"
        checked={selectedValue === 'first'}
        onChange={handleChange}
      />
      <SimRadio
        label="Second"
        disabled={false}
        name="second"
        id="second"
        checked={selectedValue === 'second'}
        onChange={handleChange}
      />
    </>
  );
};

export default Radio;

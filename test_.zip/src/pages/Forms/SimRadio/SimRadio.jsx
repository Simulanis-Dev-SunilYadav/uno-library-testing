import React from 'react';

const SimRadio = ({ checked, label, disabled, name, id, onChange }) => {
  return (
    <div className='d-flex align-items-center'>
      <input
        type="radio"
        name={name}
        id={id}
        checked={checked}
        disabled={disabled}
        onChange={onChange}
      />
      <label htmlFor={id}>{label}</label>
    </div>
  );
};

export default SimRadio;

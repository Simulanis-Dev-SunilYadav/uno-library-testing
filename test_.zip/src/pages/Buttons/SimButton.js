import React from 'react'
import { Groups, Users } from '../../Assets/Icons'
import SimRadio from '../Forms/SimRadio/SimRadio'
import Radio from '../Forms/SimRadio/Radio'

const SimButton = () => {
  return (
    <>
        <div class="create">
         <a href="#" class="button">
            <div class="icon">
                <Groups/>
            </div>
            <span>Groups</span>
         </a>
         <a href="#" class="button">
            <div class="icon">
                <Users/>
            </div>
            <span>Users</span>
         </a>
      </div>
<br />
<br />
<br />
<br />
      <Radio/>

    </>
  )
}

export default SimButton

import React from "react";
import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import FormPage from "./pages/Forms/FormPage";
import TabStyle from "./pages/Tabs/TabStyle";
import SimButton from "./pages/Buttons/SimButton";


function App() {

  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/form-page" element={<FormPage />} />
          <Route path="/tabs" element={<TabStyle />} />
          <Route path="/buttons" element={<SimButton />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
